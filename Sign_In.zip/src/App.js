
import "bootstrap/dist/css/bootstrap.min.css"
import "./css/loginform.css"
import {BrowserRouter,Routes,Route} from "react-router-dom"
import SignIn from "./routes/SignIn"
import EmailVer from "./routes/EmailVer"
import ResetPassword from "./routes/ResetPassword"


function App() {
  return (
    <BrowserRouter>
    <Routes>
    <Route path="/" element={<SignIn/>} />
    <Route path="/email" element={<EmailVer/>} />
    <Route path="/resetpass" element={<ResetPassword/>} />
    </Routes>
    </BrowserRouter>
  )
}

export default App